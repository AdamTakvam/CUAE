This is an experimental binary distribution of OpenLDAP for 32-bit
Microsoft Windows systems (e.g., Windows 98, NT, 2000, XP).  I've used
OpenLDAP profitably on Windows before, but this attempt at building
the new 2.1 series is very new, so don't bet the farm on it just yet.

Since you've gotten this far, all that's left to do is run the LDAP
server and connect to it with a client.  To run the server, adjust the
file slapd.conf if necessary, then go to a command prompt and do:

  C:\> cd \openldap
  C:\openldap> .\slapd -d 1

It will print a great deal of debugging effluvia on the console, at
which point you should be able to connect to the server with a client
program.  There is almost no Windows-specific documentation for
OpenLDAP right now, alas, so the standard documentation available at
openldap.org is your best bet on getting usage information for now.

			       CAVEATS

This is currently hackerware, especially when you're building it from
source, so expect to have to do a little messing around to get it to
work.  Also, there is TLS/SSL support in this build, but there is no
SASL support.  It turns out everything is easier to build with MinGW,
except Cyrus SASL, which expects the Microsoft toolchain.  I'll have
it worked out one way or another soon.

		     WHEN WILL FEATURE X BE READY

You're welcome to ask on the usual support channels, but I'll warn you
that I don't know, for most values of X.  If you want something to
happen (e.g., documentation, a certain software feature, etc.) by a
certain time, then the only way to guarantee it is to either do it
yourself or to hire me (or some other capable hacker) as a consultant
to do it for you.

			   TROUBLESHOOTING

I have done almost no testing on this release, but people are
currently working with it, so it should get better pretty rapidly.  In
the meantime, if you have problems or questions (about this port in
particular, not OpenLDAP in general), please discuss them on the
proper mailing list: see http://lucas.bergmans.us/hacks/openldap/.

-- 
Lucas Bergman <lucas@bergmans.us>
7 April 2004
